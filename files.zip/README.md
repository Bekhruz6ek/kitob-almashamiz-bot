# 📚 Kitob Almashamiz — Bot O'rnatish Qo'llanmasi

## 📁 Fayllar
- `bot.py` — Asosiy bot kodi
- `requirements.txt` — Kerakli kutubxonalar
- `render.yaml` — Render.com sozlamalari

---

## ⚙️ 1-QADAM: Bot Token olish

1. Telegramda **@BotFather** ni oching
2. `/newbot` yozing
3. Bot nomini yozing: `Kitob Almashamiz`
4. Bot username: `Kitob_almashamizbot`
5. BotFather sizga **TOKEN** beradi — uni saqlang!

---

## 🆔 2-QADAM: O'zingizning Telegram ID ni topish

1. **@userinfobot** ga `/start` yozing
2. U sizga ID raqamingizni ko'rsatadi
3. Uni `ADMIN_ID` ga qo'ying

---

## 📢 3-QADAM: Kanal yaratish (ixtiyoriy)

1. Telegram'da yangi kanal yarating
2. Botingizni kanal **admin** sifatida qo'shing
3. Kanal username'ni `KANAL_ID` ga qo'ying (masalan: `@Kitob_almashamiz_kanal`)

---

## 🐙 4-QADAM: GitHub ga yuklash

1. [github.com](https://github.com) ga kiring
2. **New Repository** → nom: `kitob-almashamiz-bot`
3. Public qilib yarating
4. Uchta faylni yuklang: `bot.py`, `requirements.txt`, `render.yaml`

---

## 🚀 5-QADAM: Render.com ga Deploy qilish

1. [render.com](https://render.com) ga kiring (bepul ro'yxatdan o'ting)
2. **New** → **Background Worker** tanlang
3. GitHub repo'ingizni ulang
4. **Environment Variables** qo'shing:

   | Key | Value |
   |-----|-------|
   | `BOT_TOKEN` | BotFather dan olgan token |
   | `ADMIN_ID` | Sizning Telegram ID'ingiz |
   | `KANAL_ID` | @kanal_username (yoki bo'sh qoldiring) |

5. **Create Background Worker** bosing
6. ✅ Bot 24/7 ishlaydi!

---

## 💡 Muhim eslatmalar

- **Background Worker** = hech qachon sleep bo'lmaydi (polling ishlatadi)
- Render bepul planda oyiga **750 soat** beradi — bu yetarli!
- Ma'lumotlar bot qayta ishga tushganda o'chadi — keyinroq **database** qo'shing

---

## 🔧 Funksiyalar

| Buyruq | Tavsif |
|--------|--------|
| `/start` | Botni ishga tushirish |
| `/elon` | Kitob e'lon qilish (tur, nom, holat, narx, kontakt, rasm, manzil) |
| `/qidir` | Kitob qidirish |
| `/mening_kitoblarim` | O'z e'lonlarini ko'rish + "Sotildi" tugmasi |
| `/ochirish` | E'lonni o'chirish |
| `/istaklar_qoshish` | Istak ro'yxatiga kitob qo'shish |
| `/mening_istaklarim` | Istak ro'yxatini ko'rish |
| `/barcha` | Admin: barcha e'lonlar |
| `/bekor` | Jarayonni bekor qilish |

---

## 🆙 Keyingi bosqich (kelajakda)

Agar botingiz ommalashsa, bepul **database** qo'shish mumkin:
- **Supabase** (bepul PostgreSQL)
- **MongoDB Atlas** (bepul)

Bu ma'lumotlar bot qayta ishganda saqlanib qoladi.
